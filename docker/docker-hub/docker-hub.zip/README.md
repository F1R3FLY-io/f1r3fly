## Create ZIP file

```
zip -r docker-hub.zip * .*
```